

package com.subhipandey.android.datadrop.ui.base


interface BasePresenter {
  fun start()
}