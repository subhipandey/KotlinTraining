

package com.subhipandey.android.datadrop.ui.base


interface BaseView<T> {
  var presenter: T
}

